from . import myModule
from .myModule import fibonacci
