# mypackage
1. This is a test library printing top n numbers from a list.
2. Get the fibonacci of nth number.

## Building

`python setup.py sdist`

## Installing the package from GitHub

`pip install git+https://github.com/homemix/mypackage.git`

## Updating this package from GitHub
`pip install --upgrade git+https://github.com/homemix/mypackage.git`
