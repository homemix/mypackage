# mypackage
This is a test library printing top n numbers from a list

## Building

`python setup.py sdist`

## Installing the package from GitHub

`pip install git+https://github.com/homemix/mypackage.git`

## Updating this package from GitHub
`pip install --upgrade git+https://github.com/homemix/mypackage.git`
